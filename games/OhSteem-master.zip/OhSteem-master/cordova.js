// placeholder
window.isWebApp = true;